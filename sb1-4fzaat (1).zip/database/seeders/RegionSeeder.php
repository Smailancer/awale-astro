<?php

namespace Database\Seeders;

use App\Models\Region;
use Illuminate\Database\Seeder;

class RegionSeeder extends Seeder
{
    public function run(): void
    {
        $regions = [
            [
                'wilaya' => 'Tizi Ouzou',
                'dairas' => ['Tizi Ouzou', 'Maatkas', 'Ain El Hammam', 'Draa Ben Khedda', 'Larbaa Nath Irathen'],
            ],
            [
                'wilaya' => 'Bejaia',
                'dairas' => ['Bejaia', 'Akbou', 'Sidi Aich', 'Amizour', 'Tichy'],
            ],
            [
                'wilaya' => 'Bouira',
                'dairas' => ['Ain Bessem', 'M\'Chedallah', 'Lakhdaria', 'Sour El Ghozlane'],
            ],
            [
                'wilaya' => 'Boumerdes',
                'dairas' => ['Bordj Menaiel', 'Dellys', 'Baghlia', 'Isser'],
            ],
        ];

        foreach ($regions as $region) {
            Region::create($region);
        }
    }
}