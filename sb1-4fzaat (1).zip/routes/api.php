<?php

use App\Http\Controllers\Api\WordController;
use App\Http\Controllers\Api\RegionController;
use Illuminate\Support\Facades\Route;

Route::middleware('api')->group(function () {
    Route::apiResource('words', WordController::class);
    Route::apiResource('regions', RegionController::class)->only(['index', 'store']);
});