<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Word extends Model
{
    protected $fillable = [
        'text',
        'meaning',
        'pronunciation',
        'variants',
        'regions',
    ];

    protected $casts = [
        'variants' => 'array',
        'regions' => 'array',
    ];
}