<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Word;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WordController extends Controller
{
    public function index()
    {
        return Word::all();
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'text' => 'required|string|max:255',
            'meaning' => 'required|string',
            'pronunciation' => 'required|string|max:255',
            'variants' => 'required|array',
            'variants.*' => 'string',
            'regions' => 'array',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $word = Word::create($request->all());
        return response()->json($word, 201);
    }

    public function show(Word $word)
    {
        return $word;
    }

    public function update(Request $request, Word $word)
    {
        $validator = Validator::make($request->all(), [
            'text' => 'string|max:255',
            'meaning' => 'string',
            'pronunciation' => 'string|max:255',
            'variants' => 'array',
            'variants.*' => 'string',
            'regions' => 'array',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $word->update($request->all());
        return response()->json($word);
    }

    public function destroy(Word $word)
    {
        $word->delete();
        return response()->json(null, 204);
    }
}