export const tamazightWords = [
  {
    id: "azul",
    text: "Azul",
    variants: ["Kabyle", "Tashelhit", "Rifian"],
    meaning: "Hello, Peace",
    pronunciation: "ah-zool",
    example: "Azul fellak/fellam - Hello to you",
    description: "A common greeting used across various Tamazight dialects, expressing both hello and peace.",
    usageNotes: "Used as a general greeting at any time of day.",
    regions: {
      Kabyle: [
        {
          wilaya: "Tizi Ouzou",
          dairas: ["Tizi Ouzou", "Maatkas", "Ain El Hammam"],
          pronunciation: "ah-zool",
          specific_usage: "Standard greeting"
        },
        {
          wilaya: "Bejaia",
          dairas: ["Bejaia", "Akbou", "Sidi Aich"],
          pronunciation: "ah-zool",
          specific_usage: "Common morning greeting"
        },
        {
          wilaya: "Bouira",
          dairas: ["Ain Bessem", "M'Chedallah"],
          pronunciation: "ah-zul",
          specific_usage: "Formal greeting"
        },
        {
          wilaya: "Boumerdes",
          dairas: ["Bordj Menaiel", "Dellys"],
          pronunciation: "ah-zool",
          specific_usage: "Casual greeting"
        }
      ],
      Tashelhit: {
        regions: ["Souss-Massa", "Anti-Atlas"],
        pronunciation: "ah-zool",
        specific_usage: "Used in southern Morocco"
      },
      Rifian: {
        regions: ["Al Hoceima", "Nador"],
        pronunciation: "ah-zul",
        specific_usage: "Common in northern Morocco"
      }
    }
  }
];