import { Router } from 'express';
import { TaskController } from '../controllers/taskController.js';

const router = Router();
const taskController = new TaskController();

// Health check
router.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Task routes
router.get('/tasks', taskController.getAll);
router.post('/tasks', taskController.create);
router.get('/tasks/:id', taskController.getById);
router.put('/tasks/:id', taskController.update);
router.delete('/tasks/:id', taskController.delete);

export { router };