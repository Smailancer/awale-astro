import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.PUBLIC_API_URL || 'http://localhost:8000/api',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

export const wordService = {
  async getWords() {
    try {
      const response = await api.get('/words');
      return response.data;
    } catch (error) {
      console.error('Error fetching words:', error);
      throw error;
    }
  },

  async addWord(wordData) {
    try {
      const response = await api.post('/words', wordData);
      return response.data;
    } catch (error) {
      console.error('Error adding word:', error);
      throw error;
    }
  },

  async getRegions() {
    try {
      const response = await api.get('/regions');
      return response.data;
    } catch (error) {
      console.error('Error fetching regions:', error);
      throw error;
    }
  }
};