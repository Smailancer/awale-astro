export const API_BASE_URL = import.meta.env.PUBLIC_API_URL || 'http://localhost:8000/api';

export async function fetchWords() {
  const response = await fetch(`${API_BASE_URL}/words`);
  if (!response.ok) throw new Error('Failed to fetch words');
  return response.json();
}

export async function createWord(wordData: any) {
  const response = await fetch(`${API_BASE_URL}/words`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(wordData),
    credentials: 'include',
  });
  if (!response.ok) throw new Error('Failed to create word');
  return response.json();
}

export async function updateWord(id: string, wordData: any) {
  const response = await fetch(`${API_BASE_URL}/words/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(wordData),
    credentials: 'include',
  });
  if (!response.ok) throw new Error('Failed to update word');
  return response.json();
}

export async function deleteWord(id: string) {
  const response = await fetch(`${API_BASE_URL}/words/${id}`, {
    method: 'DELETE',
    credentials: 'include',
  });
  if (!response.ok) throw new Error('Failed to delete word');
  return response.json();
}