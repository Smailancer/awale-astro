export class UserController {
  constructor() {
    this.users = [];
  }

  getAll = (req, res) => {
    res.json(this.users);
  };

  create = (req, res) => {
    const { name, email } = req.body;
    
    if (!name || !email) {
      return res.status(400).json({
        error: 'Name and email are required'
      });
    }

    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      createdAt: new Date().toISOString()
    };

    this.users.push(newUser);
    res.status(201).json(newUser);
  };

  getById = (req, res) => {
    const user = this.users.find(u => u.id === req.params.id);
    
    if (!user) {
      return res.status(404).json({
        error: 'User not found'
      });
    }

    res.json(user);
  };

  update = (req, res) => {
    const { name, email } = req.body;
    const userIndex = this.users.findIndex(u => u.id === req.params.id);
    
    if (userIndex === -1) {
      return res.status(404).json({
        error: 'User not found'
      });
    }

    this.users[userIndex] = {
      ...this.users[userIndex],
      name: name || this.users[userIndex].name,
      email: email || this.users[userIndex].email,
      updatedAt: new Date().toISOString()
    };

    res.json(this.users[userIndex]);
  };

  delete = (req, res) => {
    const userIndex = this.users.findIndex(u => u.id === req.params.id);
    
    if (userIndex === -1) {
      return res.status(404).json({
        error: 'User not found'
      });
    }

    this.users.splice(userIndex, 1);
    res.status(204).send();
  };
}