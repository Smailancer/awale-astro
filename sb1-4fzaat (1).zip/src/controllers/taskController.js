export class TaskController {
  constructor() {
    this.tasks = [];
  }

  getAll = (req, res) => {
    res.json({
      status: 'success',
      data: this.tasks
    });
  };

  create = (req, res) => {
    const { title, description } = req.body;
    
    if (!title) {
      return res.status(400).json({
        status: 'error',
        message: 'Title is required'
      });
    }

    const newTask = {
      id: Date.now().toString(),
      title,
      description,
      completed: false,
      createdAt: new Date().toISOString()
    };

    this.tasks.push(newTask);
    res.status(201).json({
      status: 'success',
      data: newTask
    });
  };

  getById = (req, res) => {
    const task = this.tasks.find(t => t.id === req.params.id);
    
    if (!task) {
      return res.status(404).json({
        status: 'error',
        message: 'Task not found'
      });
    }

    res.json({
      status: 'success',
      data: task
    });
  };

  update = (req, res) => {
    const { title, description, completed } = req.body;
    const taskIndex = this.tasks.findIndex(t => t.id === req.params.id);
    
    if (taskIndex === -1) {
      return res.status(404).json({
        status: 'error',
        message: 'Task not found'
      });
    }

    this.tasks[taskIndex] = {
      ...this.tasks[taskIndex],
      title: title || this.tasks[taskIndex].title,
      description: description || this.tasks[taskIndex].description,
      completed: completed !== undefined ? completed : this.tasks[taskIndex].completed,
      updatedAt: new Date().toISOString()
    };

    res.json({
      status: 'success',
      data: this.tasks[taskIndex]
    });
  };

  delete = (req, res) => {
    const taskIndex = this.tasks.findIndex(t => t.id === req.params.id);
    
    if (taskIndex === -1) {
      return res.status(404).json({
        status: 'error',
        message: 'Task not found'
      });
    }

    this.tasks.splice(taskIndex, 1);
    res.status(200).json({
      status: 'success',
      message: 'Task deleted successfully'
    });
  };
}