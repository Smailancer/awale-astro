document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('taskForm');
    const tasksList = document.getElementById('tasksList');

    // Fetch and display tasks
    const fetchTasks = async () => {
        try {
            const response = await fetch('/api/tasks');
            const { data } = await response.json();
            displayTasks(data);
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    };

    // Display tasks in the UI
    const displayTasks = (tasks) => {
        tasksList.innerHTML = tasks.map(task => `
            <div class="task-item p-4 border rounded-lg ${task.completed ? 'completed bg-gray-50' : 'bg-white'}" data-id="${task.id}">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <input type="checkbox" ${task.completed ? 'checked' : ''}
                               onchange="toggleTask('${task.id}', this.checked)"
                               class="h-4 w-4 text-blue-500 rounded">
                        <div>
                            <h3 class="font-medium text-gray-900">${task.title}</h3>
                            <p class="text-gray-500 text-sm">${task.description || ''}</p>
                        </div>
                    </div>
                    <button onclick="deleteTask('${task.id}')"
                            class="text-red-500 hover:text-red-700">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                    </button>
                </div>
            </div>
        `).join('');
    };

    // Add new task
    taskForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('taskTitle').value;
        const description = document.getElementById('taskDescription').value;

        try {
            const response = await fetch('/api/tasks', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ title, description }),
            });

            if (response.ok) {
                taskForm.reset();
                fetchTasks();
            }
        } catch (error) {
            console.error('Error adding task:', error);
        }
    });

    // Toggle task completion
    window.toggleTask = async (id, completed) => {
        try {
            const response = await fetch(`/api/tasks/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ completed }),
            });

            if (response.ok) {
                fetchTasks();
            }
        } catch (error) {
            console.error('Error updating task:', error);
        }
    };

    // Delete task
    window.deleteTask = async (id) => {
        if (!confirm('Are you sure you want to delete this task?')) return;

        try {
            const response = await fetch(`/api/tasks/${id}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                fetchTasks();
            }
        } catch (error) {
            console.error('Error deleting task:', error);
        }
    };

    // Initial fetch
    fetchTasks();
});